package com.example.gonzalesmaridelle_option3;

public class OnDeleteClickListener {
}
